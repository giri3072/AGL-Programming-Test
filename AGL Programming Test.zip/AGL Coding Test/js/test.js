var assert = require('assert');
var cat_owner = require('../script.js')

describe('Cat should have atleast one owner', function () {
 it('cat should have atlease one owner', function () {
      expect(cat_owner.to.exist)
    });

});
